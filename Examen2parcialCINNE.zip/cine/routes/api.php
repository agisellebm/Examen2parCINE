<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


use App\Http\Controllers\Api\FuncionesControllerapi as APIFuncionesController;
use App\Http\Controllers\Api\GenerosControllerapi as APIGenerosController;
use App\Http\Controllers\Api\PeliculasControllerapi as APIPeliculasController;
use App\Http\Controllers\Api\SalasControllerapi as APISalasController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('/funciones',
    [APIFuncionesController::class,'index'])->
    name('api.funciones.index');


Route::get('/salas',
    [APISalasController::class,'index'])->
    name('api.salas.index');


Route::get('/generos',
    [APIGenerosController::class,'index'])->
    name('api.generos.index');


Route::get('/peliculas',
    [APIPeliculasController::class,'index'])->
    name('api.funciones.index');